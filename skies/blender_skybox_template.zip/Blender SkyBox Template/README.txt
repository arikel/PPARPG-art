KatsBits tutorial and resource files
http://www.katsbits.com

USAGE
----------------------------------
Extract the files to the same location on your harddrive and open the *.blend file into Blender 2.44 or above (may cause problems when opened into pre 2.44 versions of Blender).

Read the information at the following URL for more information and details on using this file.
http://www.katsbits.com/htm/tutorials/blender_rendering_skybox_environment.htm

COPYRIGHT
----------------------------------
Copyright � 2007 Katsbits
This file is provided FREE and for NON-COMMERCIAL USE ONLY
Contact info@katsbits.com for more details.