""" YABEE (Yet another Blender's egg-exporter)
    for Blender 2.57 + 
    rev 10
"""
# -------------- Change this to setup parameters -----------------------
#: file name to write
FILE_PATH = './exp_test/test.egg' 

#: { 'animation_name' : (start_frame, end_frame, frame_rate) }
ANIMATIONS = {'anim1':(0,10,5), 
              }

#: 'True' to interprete an image in the uv layer as the texture
EXPORT_UV_IMAGE_AS_TEXTURE = False 

#: 'True' to copy texture images together with main.egg
COPY_TEX_FILES = True

#: Path for the copied textures. Relative to the main EGG file dir.
#: For example if main file path is '/home/username/test/test.egg',
#: texture path is './tex', then the actual texture path is 
#: '/home/username/test/tex'
TEX_PATH = './tex'

#: 'True' to write an animation data into the separate files
SEPARATE_ANIM_FILE = True

#: 'True' to write only animation data
ANIM_ONLY = False

#: number of sign after point
FLOATING_POINT_ACCURACY = 3
# ----------------------------------------------------------------------

import bpy, os, sys


if __name__ == '__main__':
    # Dirty hack. I can't get the script dir through the sys.argv[0] or __file__
    try:
        for text in bpy.data.texts:
            dir = os.path.dirname(text.filepath)
            if dir not in sys.path:
                sys.path.append(os.path.abspath(dir))
    except:
        print('Error while trying to add a paths in the sys.path')
        
    import yabee_libs.egg_writer
    print('RELOADING MODULES')
    import imp
    imp.reload(yabee_libs)
    imp.reload(yabee_libs.egg_writer)
    imp.reload(yabee_libs.tbn_generator)

    yabee_libs.egg_writer.write_out(FILE_PATH, 
                                    ANIMATIONS,
                                    EXPORT_UV_IMAGE_AS_TEXTURE, 
                                    SEPARATE_ANIM_FILE, 
                                    ANIM_ONLY,
                                    COPY_TEX_FILES, 
                                    TEX_PATH, 
                                    FLOATING_POINT_ACCURACY)
